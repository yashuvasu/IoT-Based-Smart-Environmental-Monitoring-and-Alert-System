# Week 1: System Requirements Analysis and Block Diagram Design

**Project:** IoT-Based Smart Environmental Monitoring and Alert System
**Author:** Pilla Yashwanth (Yuva Intern)

Week 1 plans the whole system before any code is written. The project is an ESP32-based monitor that measures temperature, humidity and air quality, shows them on an OLED, raises an LED and buzzer alert when limits are exceeded, and reports over Wi-Fi to a conceptual dashboard. It keeps monitoring locally if Wi-Fi is unavailable.

## What this folder contains

| File | Purpose |
|---|---|
| `Week1_Technical_Report_IoT_Environmental_Monitor.docx` | Full report: requirements, interfaces, power, timing, architecture, fault analysis, traceability |
| `Figure1_Block_Diagram.png` | Hardware block diagram with labelled interfaces |
| `Figure2_Software_Flowchart.png` | Start-up and monitoring-loop flowchart |

## Key content

- **26 functional** and **13 non-functional** requirements, numbered and traceable.
- Input, output, communication (I2C, GPIO, ADC, Wi-Fi) and power specifications.
- Proposed pin map, voltage-divider protection for the MQ-135, and a preliminary power estimate.
- Software modules, a state model and a fault-handling table.
- A requirement traceability matrix.

![Block diagram](Figure1_Block_Diagram.png)

## Status

This is a **proposed and simulated design**. No hardware was built or tested. All timing and power figures are design targets or datasheet-based estimates, not measurements. Week 2 turns this design into firmware.
