/* Exploratory harness: includes the firmware source (FWFILE) and probes it for defects. */
#define main fw_original_main
#include FWFILE
#undef main

static int found = 0;
#define EXPECT(cond, msg) do { if (!(cond)) { found++; printf("  DEFECT: %s (line %d)\n", msg, __LINE__); } } while (0)

static void e1_clock_wrap_warmup(void) {
    printf("E1  32-bit millisecond counter wrap (49.7 days): warm-up flag\n");
    sim_defaults(); sim_boot(RESET_POWERON); sim_run_ms(MQ_WARMUP_MS + 3000UL);
    EXPECT(g.state == ST_NORMAL && g.snap.aq_status == AQ_GOOD, "precondition: NORMAL/GOOD before wrap");
    g.ms = 0xFFFFFFFFUL - 2000UL;           /* jump the tick to 2 s before rollover */
    sim_run_ms(500);
    sim.adc_base = 1600;                    /* poor air, 0.5 s before the wrap */
    sim_run_ms(6000);                       /* run across the wrap */
    printf("      state after wrap = %s, air status = %s, g.ms=%lu\n", STATE_NAME[g.state], AQ_NAME[g.snap.aq_status], (unsigned long)g.ms);
    EXPECT(g.state != ST_WARMUP, "state falls back to WARMUP after the counter wraps");
    EXPECT(g.snap.aq_status != AQ_WARMING, "air status shows WARMING UP after the counter wraps");
}
static void e2_clock_wrap_deadlines(void) {
    printf("E2  32-bit millisecond counter wrap: display refresh and OLED retry deadlines\n");
    sim_defaults(); sim_boot(RESET_POWERON); sim_run_ms(MQ_WARMUP_MS + 3000UL);
    g.ms = 0xFFFFFFFFUL - 2500UL; g.oled_refresh_at = g.ms + OLED_FULL_REFRESH_MS; /* deadline wraps to a small number */
    uint32_t w0 = sim.oled_writes;
    sim_run_ms(3000);
    uint32_t early = sim.oled_writes - w0;
    printf("      OLED writes in the 3 s before the wrap with constant data: %lu (expected 0 before the refresh is due)\n", (unsigned long)early);
    EXPECT(early == 0, "refresh deadline computed across the wrap fires immediately (early, wasted I2C write)");
}
static void e3_threshold_change_during_alert(void) {
    printf("E3  Changing a threshold while the alert is active\n");
    sim_defaults(); sim_boot(RESET_POWERON); sim_run_ms(MQ_WARMUP_MS + 3000UL);
    for (float t = 29; t <= 36; t += 3.5f) { sim.temp = t; sim_run_ms(2100); }
    sim.temp = 36.0f; sim_run_s(6);
    EXPECT(sim.led, "precondition: alert active");
    sim_uart_send("SET TEMP_HI 33\n");     /* 36 C is still above the new, lower limit */
    sim_run_ms(50);
    printf("      LED immediately after SET: %s (36 C still exceeds the new 33 C limit)\n", sim.led ? "ON" : "OFF");
    EXPECT(sim.led, "alert is silenced by SET although the condition still holds");
}
static void e4_uart_fuzz(void) {
    printf("E4  UART fuzzing: 400000 random bytes\n");
    sim_defaults(); sim_boot(RESET_POWERON); sim_run_ms(MQ_WARMUP_MS + 3000UL);
    uint32_t r = 987654321u; int bad_order = 0;
    static const char alphabet[] = "SETHUMIDLRQ_ONF0123456789.-+e \t\r\n\0\xff";
    for (long i = 0; i < 400000; i++) {
        r = r * 1664525u + 1013904223u;
        uint8_t b = (r & 0x3F) < 40 ? (uint8_t)alphabet[(r >> 8) % (sizeof alphabet - 1)] : (uint8_t)(r >> 16);
        uart_rx_isr(b); sim_tick();
        if (g.ch[CH_TEMP_HI].trip - g.ch[CH_TEMP_LO].trip <= 2.0f * HYST_TEMP) bad_order++;
        if (g.ch[CH_HUM_HI].trip - g.ch[CH_HUM_LO].trip <= 2.0f * HYST_HUM) bad_order++;
    }
    printf("      survived; overflow counter=%u, threshold-order violations=%d\n", (unsigned)g.rx_overflow, bad_order);
    EXPECT(bad_order == 0, "threshold ordering invariant violated by fuzzed commands");
}
static void e5_worst_case_payload(void) {
    printf("E5  Worst-case telemetry payload length\n");
    sim_defaults(); sim_boot(RESET_POWERON); sim_run_ms(MQ_WARMUP_MS + 3000UL);
    g.ms = 0xFFFFFFF0UL; g.tx_seq = 4294967295UL; g.snap.temp = -40.0f; g.snap.hum = 100.0f;
    g.snap.aq_raw = 4094; g.snap.aq_status = AQ_WARMING; g.alerts = 31; g.faults = 31; sim.rssi = -100;
    g.wifi = WIFI_UP; build_and_send();
    size_t n = strlen(sim.last_payload);
    printf("      worst-case payload = %zu bytes (buffer %u)\n", n, (unsigned)PAYLOAD_MAX);
    EXPECT(n > 0 && n < PAYLOAD_MAX - 16, "payload does not fit with margin");
}

/* ---------- randomised soak test with invariant checking ---------- */
static uint32_t srnd = 20261014u;
static uint32_t rnd(void) { srnd = srnd * 1664525u + 1013904223u; return srnd >> 8; }
static float plaus(float cur, float target, float step) { return fabsf(target - cur) <= step ? target : cur + (target > cur ? step : -step); }

static long inv_fail[16];
static void check_invariants(void) {
    bool hw = (g.faults & FAULT_HW_MASK) != 0;
    if (!g.alerts && !hw && (sim.led || sim.buzzer)) inv_fail[1]++;               /* I1 outputs off when idle  */
    if (g.alerts && !sim.led) inv_fail[2]++;                                       /* I2 alert => LED on        */
    if (g.alerts && g.state != ST_ALERT) inv_fail[3]++;                            /* I3 state consistent       */
    if ((g.faults & FAULT_DHT) && (g.alerts & ((1u<<CH_TEMP_HI)|(1u<<CH_TEMP_LO)|(1u<<CH_HUM_HI)|(1u<<CH_HUM_LO)))) inv_fail[4]++; /* I4 */
    if ((g.faults & FAULT_MQ) && (g.alerts & (1u << CH_AIR))) inv_fail[5]++;      /* I5 no alert from faulty sensor */
    if (g.rx_head >= UART_RX_BUF_SIZE || g.rx_tail >= UART_RX_BUF_SIZE) inv_fail[6]++; /* I6 indices */
    for (int i = 0; i < OLED_LINES; i++) if (memchr(sim.oled[i], 0, OLED_COLS) == NULL) inv_fail[7]++; /* I7 terminated */
    if (g.state == ST_NORMAL && g.alerts) inv_fail[8]++;
    if (g.ch[CH_TEMP_HI].trip - g.ch[CH_TEMP_LO].trip <= 2.0f * HYST_TEMP) inv_fail[9]++;
}
static void e6_soak(long hours) {
    printf("E6  Randomised soak test with fault injection: %ld simulated hours (seed %u)\n", hours, 20261014u);
    sim_defaults(); sim_boot(RESET_POWERON);
    uint32_t next_event = 5000; long events = 0; uint32_t last_seq = 0; uint32_t tx_seen = 0;
    long total = hours * 3600L * 1000L;
    float tt = 25, th = 50;
    for (long ms = 0; ms < total; ms++) {
        if ((uint32_t)ms >= next_event) {
            events++; next_event = (uint32_t)ms + 3000u + rnd() % 400000u;
            switch (rnd() % 14) {
            case 0: tt = 5 + (float)(rnd() % 400) / 10.0f; break;            /* new temperature target 5..45 C */
            case 1: th = 10 + (float)(rnd() % 850) / 10.0f; break;           /* new humidity target 10..95 %   */
            case 2: sim.adc_base = 500 + (int)(rnd() % 2200); break;
            case 3: sim.dht_fail = !sim.dht_fail; break;
            case 4: sim.adc_force = (sim.adc_force < 0) ? (int)((rnd() & 1) ? 0 : 4095) : -1; break;
            case 5: sim.oled_present = !sim.oled_present; break;
            case 6: sim.wifi_ap_up = !sim.wifi_ap_up; break;
            case 7: sim.send_ok = !sim.send_ok; break;
            case 8: { static const char *cmds[] = {"STATUS\n", "THRESH\n", "SET TEMP_HI 30\n", "SET TEMP_HI 35\n", "MUTE ON\n", "MUTE OFF\n", "SET HUM_LO 25\n", "SET TEMP_LO 12\n", "garbage??\n"};
                      sim_uart_send(cmds[rnd() % 9]); break; }
            case 9: if (rnd() % 4 == 0) sim_boot((rnd() & 1) ? RESET_BROWNOUT : RESET_POWERON); break;
            default: break;
            }
        }
        if (ms % 1000 == 0) { sim.temp = plaus(sim.temp, tt, 3.0f); sim.hum = plaus(sim.hum, th, 10.0f); } /* plausible changes only */
        sim_tick();
        if (ms % 50 == 0) check_invariants();
        if (sim.tx_count != tx_seen) {
            tx_seen = sim.tx_count; const char *p = strstr(sim.last_payload, "\"seq\":");
            unsigned long s = 0; if (p) sscanf(p + 6, "%lu", &s);
            if (s != 0 && s <= last_seq && !(sim.uart_len == 0)) { /* sequence restarts only after a reset */ }
            last_seq = (uint32_t)s;
            if (strlen(sim.last_payload) >= PAYLOAD_MAX - 1) inv_fail[10]++;
        }
    }
    printf("      events=%ld, watchdog resets=%lu, transmissions=%lu, reboots(sim)=%lu\n", events, (unsigned long)sim.reboots, (unsigned long)sim.tx_count, (unsigned long)sim.reboots);
    const char *names[] = {"", "I1 outputs OFF when idle", "I2 alert => LED on", "I3 alert => state ALERT", "I4 no temp/hum alert during DHT fault",
        "I5 no AIR alert during MQ fault", "I6 ring buffer indices in range", "I7 OLED lines terminated", "I8 NORMAL => no alerts", "I9 threshold ordering", "I10 payload within buffer"};
    for (int i = 1; i <= 10; i++) { printf("      %-40s violations: %ld\n", names[i], inv_fail[i]); EXPECT(inv_fail[i] == 0, names[i]); }
    EXPECT(sim.reboots == 0, "watchdog expired during the soak test");
}

int main(int argc, char **argv) {
    long hours = argc > 1 ? atol(argv[1]) : 6;
    printf("Exploratory bug hunt on %s\n", FWFILE);
    e1_clock_wrap_warmup();
    e2_clock_wrap_deadlines();
    e3_threshold_change_during_alert();
    e4_uart_fuzz();
    e5_worst_case_payload();
    e6_soak(hours);
    printf("\nDefects / violations reported: %d\n", found);
    return 0;
}
