/* Benchmark harness: deterministic scenario, behaviour fingerprint and resource counters. */
#define main fw_original_main
#include FWFILE
#undef main

static float target_temp(long s) { return (s >= 200 && s < 260) ? 36.0f : 24.0f + 2.0f * sinf((float)s * 6.2831853f / 300.0f); }
static float target_hum(long s) { return 50.0f + 8.0f * sinf((float)s * 6.2831853f / 420.0f); }

int main(int argc, char **argv) {
    long seconds = argc > 1 ? atol(argv[1]) : 600;
    sim_defaults();
    sim_boot(RESET_POWERON);
    uint64_t hash = 1469598103934665603ULL; /* FNV-1a over (time, alerts, led, buzzer-phase-independent state) */
    uint32_t last_alerts = 0; bool last_led = false; sys_state_t last_state = ST_INIT; wifi_state_t last_wifi = WIFI_CONNECTING;
    long events = 0;
    for (long s = 0; s < seconds; s++) {
        float tt = target_temp(s), th = target_hum(s);
        sim.temp += fabsf(tt - sim.temp) <= 3.0f ? (tt - sim.temp) : (tt > sim.temp ? 3.0f : -3.0f);
        sim.hum += fabsf(th - sim.hum) <= 8.0f ? (th - sim.hum) : (th > sim.hum ? 8.0f : -8.0f);
        sim.wifi_ap_up = !(s >= 300 && s < 330);
        for (int ms = 0; ms < 1000; ms++) {
            sim_tick();
            if (g.alerts != last_alerts || sim.led != last_led || g.state != last_state) {
                uint32_t rec[4] = {(uint32_t)sim.total_ms, g.alerts, (uint32_t)sim.led, (uint32_t)g.state};
                for (size_t i = 0; i < sizeof rec; i++) { hash ^= ((uint8_t *)rec)[i]; hash *= 1099511628211ULL; }
                last_alerts = g.alerts; last_led = sim.led; last_state = g.state; last_wifi = g.wifi; events++;
            }
        }
    }
    unsigned long bytes;
#ifdef HAVE_OLED_BYTES
    bytes = (unsigned long)sim.oled_bytes;
#else
    bytes = (unsigned long)sim.oled_writes * 1024UL; /* baseline writes full 1024-byte frames */
#endif
    printf("scenario_seconds=%ld\n", seconds);
    printf("behaviour_events=%ld alert_hash=%016llx\n", events, (unsigned long long)hash);
    printf("oled_writes=%lu oled_bytes=%lu i2c_time_ms_at_400kHz=%.1f\n", (unsigned long)sim.oled_writes, bytes, (double)bytes * 9.0 / 400.0);
    printf("telemetry_messages=%lu wifi_attempts=%lu\n", (unsigned long)sim.tx_count, (unsigned long)sim.attempts);
    printf("dht_ok=%lu mq_samples=%lu\n", (unsigned long)g.stat.dht_ok, (unsigned long)g.stat.mq_samples);
    printf("sizeof_fw_t=%zu\n", sizeof(fw_t));
    return 0;
}
